package event;

import java.awt.Component;
import swing.DataSearch;

public interface EventClick {

    public void itemClick(DataSearch data);
}