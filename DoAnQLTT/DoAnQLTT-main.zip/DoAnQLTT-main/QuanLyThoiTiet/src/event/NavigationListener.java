package event;

public interface NavigationListener {

    void onNext();

    void onPrevious();
}
